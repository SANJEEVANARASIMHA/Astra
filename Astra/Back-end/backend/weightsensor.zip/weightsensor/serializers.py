from rest_framework import serializers

from weightsensor.models import  SensorReading, SensorDaily


class SensorLiveSerializer(serializers.Serializer):
    wastage = serializers.FloatField()
    totalweight = serializers.FloatField()


class SensorReadingLiveSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorReading
        fields = "__all__"


class SensorDailyLiveSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorDaily
        fields = "__all__"


class SensorDailyRawSerializer(serializers.Serializer):
    # id = serializers.IntegerField()
    reading = serializers.FloatField()
    timestamp = serializers.DateTimeField()

class SensorUniqueSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorDaily
        fields = ['id','tagid', 'timestamp']
