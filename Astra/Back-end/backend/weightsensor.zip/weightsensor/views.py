import datetime
import math
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Sum
from weightsensor.models import SensorDaily, SensorReading
from weightsensor.serializers import SensorDailyLiveSerializer, SensorUniqueSerializer


class SensorWastageAPIView(APIView):

    def get(self, request):
        try:
            daily_objects = SensorReading.objects.raw(
                'select distinct tagid, max(timestamp) as timestamp, id from weightsensor_sensorreading group by tagid;')
            if daily_objects:
                print(len(daily_objects))
                serializer = SensorUniqueSerializer(daily_objects, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response([], status=status.HTTP_200_OK)
        except Exception as err:
            return Response({"error": str(err)}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:
            currentDate = datetime.datetime.today().date()
            id = request.data.get('tagid')

            # daily_objects = SensorDaily.objects.filter(timestamp__startswith=currentDate).exclude(
            # dcstatus=1).order_by( '-timestamp').first()
            #
            # daily_objects = SensorDaily.objects.filter(tagid=id, timestamp__startswith=currentDate).exclude(dcstatus=1).order_by(
            #     '-timestamp').first()

            daily_objects = SensorDaily.objects.filter(tagid=id).order_by('-timestamp').first()
            print(daily_objects)

            if daily_objects:
                serializer = SensorDailyLiveSerializer(daily_objects)
                print("------", serializer.data)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response(
                    {"tagid": "", "reading": 0, "distancelader": 0, "dcstatus": 0, "battery": 0, "timestamp": ""},
                    status=status.HTTP_200_OK)
        except Exception as err:
            return Response({"error": str(err)}, status=status.HTTP_400_BAD_REQUEST)


class NewSensorGraphAPI(APIView):

    def get(self, request):
        try:
            weekly_list = []
            monthly_list = []
            dataPayload = []
            graph = request.GET.get('key')
            id = request.GET.get('tagid')
            currentDate = datetime.datetime.now().date()
            for row in range(0, 8):
                a = currentDate - datetime.timedelta(days=row)
                weekly_list.append(a)
            weekly_list.reverse()

            for row in range(1, 32):
                a = currentDate - datetime.timedelta(days=row)
                if str(currentDate)[0:7] == str(a)[0:7]:
                    monthly_list.append(str(a))
            monthly_list.reverse()

            if graph == "weekly":
                for date in weekly_list:
                    print(date)
                    payload = self.creatingPayload(date, id)
                    if payload:
                        dataPayload.append(payload)
                return Response(dataPayload, status=status.HTTP_200_OK)
            elif graph == "monthly":
                for date in monthly_list:
                    print(date)
                    payload = self.creatingPayload(date, id)
                    print(payload)
                    if payload:
                        dataPayload.append(payload)
                return Response(dataPayload, status=status.HTTP_200_OK)
            else:
                return Response(status=status.HTTP_200_OK)
        except Exception as err:
            print(err)
            return Response({"error": str(err)}, status=status.HTTP_400_BAD_REQUEST)

    def creatingPayload(self, date, id):
        print(id)
        data = {}
        daily_objects = SensorDaily.objects.filter(tagid=id, timestamp__startswith=str(date),
                                                   dcstatus=1).aggregate(Sum('reading'))

        if daily_objects:
            print(daily_objects['reading__sum'], "---------------")
            if daily_objects['reading__sum']:
                data['date'] = date
                data['reading'] = daily_objects['reading__sum']
                return data
            else:
                daily_objects = SensorDaily.objects.filter(tagid=id, timestamp__startswith=str(date),
                                                           dcstatus=0).order_by('-timestamp').first()
                print("else block")
                if daily_objects:
                    data['date'] = date
                    data['reading'] = daily_objects.reading
                    return data
                else:
                    return None
        else:
            return None
