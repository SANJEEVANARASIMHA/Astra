from django.db import models


class SensorReading(models.Model):
    tagid = models.CharField(default=None, max_length=100)
    reading = models.FloatField(default=0.0, null=True)
    distancelader = models.FloatField(default=0.0, null=True)
    dcstatus = models.IntegerField(default=0, null=True)
    battery = models.FloatField(default=0.0, null=True)
    timestamp = models.DateTimeField(auto_now=True)


class SensorDaily(models.Model):
    tagid = models.CharField(default=None, max_length=100)
    reading = models.FloatField(default=0.0, null=True)
    distancelader = models.FloatField(default=0.0, null=True)
    dcstatus = models.IntegerField(default=0, null=True)
    battery = models.FloatField(default=0.0, null=True)
    timestamp = models.DateTimeField(auto_now=True)
